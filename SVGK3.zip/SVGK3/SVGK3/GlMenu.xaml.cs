﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SVGK3
{
    /// <summary>
    /// Логика взаимодействия для GlMenu.xaml
    /// </summary>
    public partial class GlMenu : Window
    {
        public GlMenu()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Clients cl = new Clients();
            cl.Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Projects proj = new Projects();
            proj.Show();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Smets smets = new Smets();
            smets.Show();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Vipolnenie vipoln = new Vipolnenie();
            vipoln.Show();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Sravnenie sravn = new Sravnenie();
            sravn.Show();
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Hide();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Hide();
        }
    }
}
