﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SVGK3
{
    public partial class Projects : Form
    {
        DBDB dbNEW = new DBDB();
        public Projects()
        {
            InitializeComponent();
        }

        private void RSR(DataGridView dgw, IDataRecord rec)
        {
            dgw.Rows.Add(rec.GetInt32(0), rec.GetString(1), rec.GetDecimal(2), rec.GetDecimal(3));
        }

        private void projectsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.projectsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.svgkDBNEEEEWDataSet);

        }

        private void Projects_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "svgkDBNEEEEWDataSet.Projects". При необходимости она может быть перемещена или удалена.
            this.projectsTableAdapter.Fill(this.svgkDBNEEEEWDataSet.Projects);

        }

        private void Search(DataGridView dgw)
        {
            dgw.Rows.Clear();
            string searchString = $"select * from svgkDBNEEEEW where concat (ID, Status, SMR_project, PNR_project) like '%" + txtSearch.Text + "%'";
            SqlCommand com = new SqlCommand(searchString, dbNEW.getCon());
            dbNEW.openCon();
            SqlDataReader read = com.ExecuteReader();

            while (read.Read())
            {
                RSR(dgw, read);
            }
            read.Close();
        }

        private void projectsDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {
           
        }

        private void back_Click_1(object sender, EventArgs e)
        {
            GlMenu glm = new GlMenu();
            glm.Show();
            this.Hide();
        }
    }
}
