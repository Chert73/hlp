﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace SVGK3
{
    /// <summary>
    /// Логика взаимодействия для Regisr.xaml
    /// </summary>
    public partial class Regisr : Window
    {
        public Regisr()
        {
            InitializeComponent();

        }
        DBDB dbNew = new DBDB();
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();

            var login = txtlogin.Text;
            var password = txtPassword.Text;
            string name = txtName.Text;
            string dolj = txtDoljnost.Text;
            string zapros = $"insert into Sotrudniki(Login, Password, Doljnost, Name) values('{login}', '{password}', '{dolj}', '{name}')";
            SqlCommand command = new SqlCommand(zapros, dbNew.getCon());
            dbNew.openCon();
            if (command.ExecuteNonQuery() == 1 & txtpass2.Text == txtPassword.Text & txtlogin.Text != "" & txtPassword.Text != "" & txtName.Text != "" & txtDoljnost.Text != "")
            {
                MessageBox.Show("Аккаунт успешно зарегистррован!");
                mw.Show();
                this.Hide();
            }
            if (command.ExecuteNonQuery() != 1)
            {
                MessageBox.Show("Возникла проблема с подключением к базе данных.");
            }

            if (txtpass2.Text != txtPassword.Text)
            {
                MessageBox.Show("Вы неверно повторили пароль!");
            }

            if (txtlogin.Text == "" || txtPassword.Text == "" || txtName.Text == "" || txtDoljnost.Text == "")
            {
                MessageBox.Show("Пожалуйста, заполните пустые поля!");
            }

            dbNew.closeCon();
        }
        private Boolean proverka()
        {
            var login2 = txtlogin.Text;
            var password2 = txtPassword.Text;
            string name2 = txtName.Text;
            string dolj2 = txtDoljnost.Text;
            SqlDataAdapter adap = new SqlDataAdapter();
            DataTable table = new DataTable();
            string zapros2 = $"select ID, Login, Password, Doljnost, Name from Sotrudniki where Login = '{login2}'and Password = '{password2}' and Doljnost = '{dolj2}' and Name = '{name2}'";
            SqlCommand com = new SqlCommand(zapros2, dbNew.getCon());
            adap.SelectCommand = com;
            adap.Fill(table);
            if (table.Rows.Count > 0)
            {
                MessageBox.Show("Кажется, такой пользователь уже существует в базе данных.");
                return true;
            }
            else
            {
                return false;
                
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Hide();
        }
    }
}
