﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SVGK3
{
    /// <summary>
    /// Логика взаимодействия для Smets.xaml
    /// </summary>
    public partial class Smets : Window
    {
        public Smets()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {

            SVGK3.svgkDBNEEEEWDataSet svgkDBNEEEEWDataSet = ((SVGK3.svgkDBNEEEEWDataSet)(this.FindResource("svgkDBNEEEEWDataSet")));
            // Загрузить данные в таблицу Smeti. Можно изменить этот код как требуется.
            SVGK3.svgkDBNEEEEWDataSetTableAdapters.SmetiTableAdapter svgkDBNEEEEWDataSetSmetiTableAdapter = new SVGK3.svgkDBNEEEEWDataSetTableAdapters.SmetiTableAdapter();
            svgkDBNEEEEWDataSetSmetiTableAdapter.Fill(svgkDBNEEEEWDataSet.Smeti);
            System.Windows.Data.CollectionViewSource smetiViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("smetiViewSource")));
            smetiViewSource.View.MoveCurrentToFirst();
        }
    }
}
