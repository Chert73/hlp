﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SVGK3
{
    public partial class Vipolnenie : Form
    {
        public Vipolnenie()
        {
            InitializeComponent();
        }

        private void dop_soglashenieBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.dop_soglashenieBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.svgkDBNEEEEWDataSet);

        }

        private void Vipolnenie_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "svgkDBNEEEEWDataSet.Dop_soglashenie". При необходимости она может быть перемещена или удалена.
            this.dop_soglashenieTableAdapter.Fill(this.svgkDBNEEEEWDataSet.Dop_soglashenie);

        }

        private void back_Click(object sender, EventArgs e)
        {
            GlMenu glm = new GlMenu();
            glm.Show();
            this.Hide();
        }
    }
}
